package com.example.android.project3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
int score=0;
RadioGroup radioGroup;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

   public void submit(View view){
        RadioButton q1=findViewById(R.id.rb2q1);
        boolean isq1 =q1.isChecked();

       RadioButton q2= (RadioButton) findViewById(R.id.rb4q2);
       boolean isq2 = q2.isChecked();
       RadioButton q3= (RadioButton) findViewById(R.id.rb2q3);
       boolean isq3 = q3.isChecked();
       RadioButton q4= (RadioButton) findViewById(R.id.rb3q4);
       boolean isq4 = q4.isChecked();
       RadioButton q5= (RadioButton) findViewById(R.id.rb3q5);
       boolean isq5 = q5.isChecked();
       CheckBox icecream = (CheckBox) findViewById(R.id.icecream) ;
       boolean hasicecream = icecream.isChecked();
       CheckBox dount= (CheckBox) findViewById(R.id.donut);
       boolean hasdount= dount.isChecked();
       int marks=calculateMarks(isq1,isq2,isq3,isq4,isq5,hasicecream,hasdount);

       Toast.makeText(this, "Your Total Marks Are = "+marks, Toast.LENGTH_SHORT).show();



   }
   private int calculateMarks(boolean addq1, boolean addq2,boolean addq3,boolean addq4,boolean addq5,boolean addice,boolean adddonut){
      if(addq1==true){
          score+=5;
      }
       if(addq2==true){
           score+=5;
       }if(addq3==true){
           score+=5;
       }if(addq4==true){
           score+=5;
       }if(addq5==true){
           score+=5;
       }
       if(addice==true){
           score+=5;
       }
       if(adddonut==true){
           score+=5;

       }
       return score;

   }
   public void onClear(View view){
      score=0;
       Toast.makeText(this, "Please start again", Toast.LENGTH_SHORT).show();
   }
    }




